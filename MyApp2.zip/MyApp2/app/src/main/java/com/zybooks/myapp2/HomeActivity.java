package com.zybooks.myapp2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    EditText date;
    EditText weight;
    Button insert;
    Button update;
    Button view;
    Button delete;
    DBHelper2 DB;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    date = findViewById(R.id.date);
    weight= findViewById(R.id.weight);
    insert=findViewById(R.id.btnInsert);
    update=findViewById(R.id.btnUpdate);
    view=findViewById(R.id.btnView);
    delete=findViewById(R.id.btnDelete);
    DB = new DBHelper2(this);





        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTXT = date.getText().toString();
                String weightTXT = weight.getText().toString();

                boolean checkinsertdata = DB.insertuserdata(dateTXT, weightTXT);
                if (checkinsertdata == true) {
                    Toast.makeText(HomeActivity.this, "New entry inserted", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(HomeActivity.this, "Entry inserted", Toast.LENGTH_SHORT).show();
                }
            }


        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTXT = date.getText().toString();


                Boolean checkdeletedata = DB.deletedata(dateTXT);
                if (checkdeletedata == true) {
                    Toast.makeText(HomeActivity.this, "New entry deleted", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(HomeActivity.this, "Entry not deleted", Toast.LENGTH_SHORT).show();
                }
            }


        });

       view.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Cursor result = DB.getdata();
               if(result.getCount()==0){
                   Toast.makeText(HomeActivity.this, "Not found", Toast.LENGTH_SHORT).show();
                   return;
               }
               StringBuffer buffer = new StringBuffer();
               while (result.moveToNext()){
                   buffer.append("date :" +result.getString(0)+"\n");
                   buffer.append("weight :" +result.getString(1)+"\n\n");
                   
               }
               AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
               builder.setCancelable(true);
               builder.setTitle("User Entries");
               builder.setMessage(buffer.toString());
               builder.show();
           }
       });







}
}